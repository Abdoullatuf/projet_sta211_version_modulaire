#modules/modeling/importance.py


import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.inspection import permutation_importance
from pathlib import Path


def compute_permutation_importance(
    model,
    X_test,
    y_test,
    model_name: str,
    imputation_method: str,
    output_dir: Path,
    top_n: int = 20,
    random_state: int = 42,
    n_repeats: int = 10,
    scoring: str = "f1",
    verbose: bool = True
) -> pd.DataFrame:
    """
    Calcule et sauvegarde l'importance des variables par permutation pour un modèle donné.

    :param model: Modèle entraîné (doit avoir `predict_proba` ou `predict`)
    :param X_test: Features de test
    :param y_test: Cible de test
    :param model_name: Nom du modèle ("Random Forest", "Stacking", etc.)
    :param imputation_method: "KNN" ou "MICE"
    :param output_dir: Dossier de sauvegarde pour le CSV et la figure
    :param top_n: Nombre de variables à afficher dans la figure
    :param random_state: Aléatoire pour reproductibilité
    :param n_repeats: Nombre de permutations
    :param scoring: Métrique de permutation (par défaut "f1")
    :param verbose: Affichage des logs
    :return: DataFrame trié des importances
    """
    if verbose:
        print(f"🔎 Importance des variables — {model_name} ({imputation_method})")
        print(f"➡️ Données : {X_test.shape[0]} obs. | {X_test.shape[1]} variables")

    # Calcul des importances par permutation
    result = permutation_importance(
        model, X_test, y_test,
        n_repeats=n_repeats,
        random_state=random_state,
        scoring=scoring
    )

    importance_df = pd.DataFrame({
        "Variable": X_test.columns,
        "Importance": result.importances_mean,
        "Écart-type": result.importances_std
    }).sort_values(by="Importance", ascending=False)

    # 📊 Affichage graphique
    if verbose:
        top_vars = importance_df.head(top_n)
        plt.figure(figsize=(8, 8))
        sns.barplot(data=top_vars, x="Importance", y="Variable", color='royalblue')
        plt.title(f"📊 Top {top_n} Variables importantes — {model_name} ({imputation_method})")
        plt.xlabel("Importance moyenne (permutation)")
        plt.tight_layout()
        plt.show()

        print("\n🔝 Top 5 variables :")
        print(top_vars.head(5).to_string(index=False))

    # 💾 Sauvegarde
    filename = f"importance_{model_name.lower().replace(' ', '_')}_{imputation_method.lower()}.csv"
    csv_path = output_dir / filename
    importance_df.to_csv(csv_path, index=False)

    if verbose:
        print(f"✅ Importances sauvegardées dans : {csv_path.name}")

    return importance_df
