#modules/modeling/load_model_artifacts.py


import joblib
import json
from pathlib import Path

def load_model_artifacts(model_name: str, dataset: str, base_paths: dict) -> dict:
    """
    Recharge les artefacts d'un modèle : objet, seuil, métriques, hyperparamètres.

    :param model_name: nom du modèle (ex: "RandomForestClassifier")
    :param dataset: nom du jeu de données ("KNN", "MICE", etc.)
    :param base_paths: dictionnaire `paths` contenant les chemins du projet
    :return: dict avec modèle, seuil, métriques, hyperparams
    """
    suffix = f"{model_name}_{dataset.upper()}"

    model_path = Path(base_paths["MODELS_DIR"]) / f"best_model_{suffix}.joblib"
    threshold_path = Path(base_paths["THRESHOLDS_DIR"]) / f"optimal_threshold_{suffix}.json"
    metrics_path = Path(base_paths["OUTPUTS_DIR"]) / "modeling" / "metrics" / f"metrics_{suffix}.json"
    hyperparams_path = Path(base_paths["OUTPUTS_DIR"]) / "modeling" / "metrics" / f"hyperparams_{suffix}.json"

    # Chargements
    model = joblib.load(model_path)
    with open(threshold_path, "r") as f:
        threshold = json.load(f)["optimal_threshold"]
    with open(metrics_path, "r") as f:
        metrics = json.load(f)

    hyperparams = None
    if hyperparams_path.exists():
        with open(hyperparams_path, "r") as f:
            hyperparams = json.load(f)

    print(f"📦 Modèle chargé : {model_name} ({dataset})")
    return {
        "model": model,
        "threshold": threshold,
        "metrics": metrics,
        "hyperparams": hyperparams,
    }
