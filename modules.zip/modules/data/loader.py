# modules/data/loader.py
"""
Module de chargement des données pour le projet STA211

Structure des données Internet Advertisements:
- X1, X2, X3: Variables quantitatives (height, width, aratio)
- X4, X5, X6, ...: Variables binaires (0/1) - mots-clés et features URL
- outcome: Variable cible (au lieu de ad.)
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Dict, List, Optional
import logging

logger = logging.getLogger(__name__)

# Configuration des colonnes adaptée à la vraie structure
QUANTITATIVE_COLS = ['X1', 'X2', 'X3']  # Variables continues
TARGET_COL = 'outcome'  # Variable cible (au lieu de ad.)

# Mapping pour la documentation
COLUMN_MAPPING = {
    'X1': 'height (hauteur)',
    'X2': 'width (largeur)', 
    'X3': 'aratio (ratio d\'aspect)',
    'X4': 'variable_binaire (première feature)',
    'outcome': 'target (publicité ou non)'
}

def detect_csv_structure(file_path: Path) -> Dict:
    """
    Détecte automatiquement la structure d'un fichier CSV
    
    Parameters:
    -----------
    file_path : Path
        Chemin vers le fichier CSV
        
    Returns:
    --------
    Dict
        Informations sur la structure du fichier
    """
    try:
        # Lecture des premières lignes pour analyse
        sample = pd.read_csv(file_path, nrows=10)
        
        structure = {
            'has_header': True,
            'columns': list(sample.columns),
            'n_columns': len(sample.columns),
            'shape_sample': sample.shape,
            'dtypes': sample.dtypes.to_dict()
        }
        
        # Détection de la variable cible (priorité à 'outcome')
        target_candidates = ['outcome', 'ad.', 'ad', 'target', 'label', 'class']
        detected_target = None
        
        for candidate in target_candidates:
            if candidate in sample.columns:
                detected_target = candidate
                break
        
        structure['target_column'] = detected_target
        
        # Détection des colonnes quantitatives (X1, X2, X3)
        quantitative_found = []
        for col in QUANTITATIVE_COLS:
            if col in sample.columns:
                quantitative_found.append(col)
        
        structure['quantitative_columns'] = quantitative_found
        
        # Détection des colonnes X4, X5, X6... (variables binaires)
        x_pattern_cols = [col for col in sample.columns 
                          if col.startswith('X') and col not in QUANTITATIVE_COLS]
        
        # Tri par numéro pour X4, X5, X6...
        x_pattern_cols.sort(key=lambda x: int(x[1:]) if x[1:].isdigit() else float('inf'))
        structure['binary_columns'] = x_pattern_cols
        
        # Analyse de X4 spécifiquement (problème float->int)
        if 'X4' in sample.columns:
            x4_values = sample['X4'].dropna().unique()
            x4_is_binary = all(val in [0, 1, 0.0, 1.0] for val in x4_values)
            structure['x4_is_binary'] = x4_is_binary
            structure['x4_unique_values'] = sorted(x4_values)
        
        # Analyse de la variable outcome
        if detected_target and detected_target in sample.columns:
            target_values = sample[detected_target].dropna().unique()
            structure['target_unique_values'] = sorted(target_values)
        
        logger.info(f"Structure détectée: {structure['n_columns']} colonnes")
        logger.info(f"Variables quantitatives: {quantitative_found}")
        logger.info(f"Variables binaires X4+: {len(x_pattern_cols)}")
        logger.info(f"Variable cible: {detected_target}")
        
        return structure
        
    except Exception as e:
        logger.error(f"Erreur détection structure: {e}")
        raise

def clean_binary_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Nettoie les colonnes binaires (conversion X4 float->int, etc.)
    
    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame à nettoyer
        
    Returns:
    --------
    pd.DataFrame
        DataFrame avec colonnes binaires nettoyées
    """
    df_cleaned = df.copy()
    
    # Détection des colonnes X4, X5, X6...
    x_cols = [col for col in df.columns if col.startswith('X') and col not in QUANTITATIVE_COLS]
    
    for col in x_cols:
        if col in df_cleaned.columns:
            # Vérification que c'est bien binaire
            unique_vals = df_cleaned[col].dropna().unique()
            
            # Si les valeurs sont dans [0, 1] ou [0.0, 1.0]
            if all(val in [0, 1, 0.0, 1.0] for val in unique_vals):
                # Conversion en int (avec gestion des NaN)
                df_cleaned[col] = df_cleaned[col].astype('Int64')  # Int64 gère les NaN
                logger.debug(f"Colonne {col} convertie en binaire (Int64)")
            else:
                logger.warning(f"Colonne {col} n'est pas binaire: valeurs uniques = {unique_vals}")
    
    return df_cleaned

def validate_files_exist(file_paths: List[Path]) -> None:
    """Valide l'existence des fichiers de données"""
    missing_files = []
    
    for file_path in file_paths:
        if not file_path.exists():
            missing_files.append(file_path.name)
        else:
            size_mb = file_path.stat().st_size / (1024 * 1024)
            logger.debug(f"Fichier trouvé: {file_path.name} ({size_mb:.1f} MB)")
    
    if missing_files:
        error_msg = f"Fichiers manquants: {missing_files}"
        logger.error(error_msg)
        raise FileNotFoundError(error_msg)

def validate_loaded_data(train_df: pd.DataFrame, test_df: pd.DataFrame, target_col: str) -> None:
    """Valide les données après chargement"""
    
    # Vérification de la cohérence entre train/test
    if train_df.shape[1] != test_df.shape[1]:
        logger.warning(f"Incohérence colonnes: Train {train_df.shape[1]} vs Test {test_df.shape[1]}")
    
    # Vérification des colonnes quantitatives X1, X2, X3
    missing_quant_cols = [col for col in QUANTITATIVE_COLS if col not in train_df.columns]
    if missing_quant_cols:
        logger.warning(f"Colonnes quantitatives manquantes: {missing_quant_cols}")
    
    # Vérification de X4 (première variable binaire)
    if 'X4' in train_df.columns:
        x4_unique = train_df['X4'].dropna().unique()
        if not all(val in [0, 1] for val in x4_unique):
            logger.warning(f"X4 contient des valeurs non-binaires: {x4_unique}")
    
    # Vérification de la variable cible
    if target_col and target_col not in train_df.columns:
        available_cols = list(train_df.columns)
        logger.error(f"Variable cible '{target_col}' manquante. Colonnes disponibles: {available_cols}")
        raise ValueError(f"Variable cible '{target_col}' manquante dans train")
    
    # Vérification des valeurs de la variable cible
    if target_col and target_col in train_df.columns:
        target_unique = train_df[target_col].dropna().unique()
        logger.info(f"Variable cible '{target_col}' - valeurs uniques: {sorted(target_unique)}")
    
    logger.info("Validation des données réussie")

def load_raw_datasets(data_dir: Path, train_filename: str = "data_train.csv", 
                     test_filename: str = "data_test.csv") -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Charge les datasets CSV d'entraînement et de test
    
    Parameters:
    -----------
    data_dir : Path
        Répertoire contenant les fichiers de données
    train_filename : str
        Nom du fichier d'entraînement
    test_filename : str
        Nom du fichier de test
        
    Returns:
    --------
    Tuple[pd.DataFrame, pd.DataFrame]
        (train_df, test_df) - DataFrames chargés et nettoyés
    """
    
    # Chemins des fichiers
    train_file = data_dir / train_filename
    test_file = data_dir / test_filename
    
    logger.info(f"Chargement depuis: {data_dir}")
    logger.info(f"Fichiers: {train_filename}, {test_filename}")
    
    # Vérification de l'existence
    validate_files_exist([train_file, test_file])
    
    try:
        # Détection de structure sur le fichier train
        train_structure = detect_csv_structure(train_file)
        logger.info(f"Structure détectée - Colonnes: {train_structure['n_columns']}")
        
        # Chargement train
        logger.info("Chargement dataset d'entraînement...")
        train_df = pd.read_csv(train_file, na_values=['?', 'NULL', 'null', '', 'nan', 'NaN'])
        
        # Chargement test
        logger.info("Chargement dataset de test...")
        test_df = pd.read_csv(test_file, na_values=['?', 'NULL', 'null', '', 'nan', 'NaN'])
        
        # Nettoyage des colonnes binaires (X4, X5, X6...)
        logger.info("Nettoyage des variables binaires...")
        train_df = clean_binary_columns(train_df)
        test_df = clean_binary_columns(test_df)
        
        # Validation post-chargement
        target_col = train_structure.get('target_column')
        validate_loaded_data(train_df, test_df, target_col)
        
        logger.info(f"Chargement réussi - Train: {train_df.shape}, Test: {test_df.shape}")
        
        return train_df, test_df
        
    except Exception as e:
        logger.error(f"Erreur lors du chargement: {e}")
        raise

def get_data_summary(train_df: pd.DataFrame, test_df: pd.DataFrame) -> Dict:
    """Génère un résumé détaillé des données chargées"""
    
    # Détection automatique des types de colonnes
    numeric_cols = train_df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = train_df.select_dtypes(exclude=[np.number]).columns.tolist()
    
    # Détection de la variable cible (priorité à 'outcome')
    target_candidates = ['outcome', 'ad.', 'ad', 'target', 'label', 'class']
    target_col = None
    for candidate in target_candidates:
        if candidate in train_df.columns:
            target_col = candidate
            break
    
    # Séparation des types de variables
    quantitative_present = [col for col in QUANTITATIVE_COLS if col in train_df.columns]
    
    # Variables binaires (X4, X5, X6...)
    binary_cols = [col for col in train_df.columns 
                   if col.startswith('X') and col not in quantitative_present and col != target_col]
    binary_cols.sort(key=lambda x: int(x[1:]) if x[1:].isdigit() else float('inf'))
    
    summary = {
        'train': {
            'shape': train_df.shape,
            'memory_mb': train_df.memory_usage(deep=True).sum() / (1024**2),
            'missing_cells': train_df.isnull().sum().sum(),
            'missing_percentage': (train_df.isnull().sum().sum() / (train_df.shape[0] * train_df.shape[1])) * 100
        },
        'test': {
            'shape': test_df.shape,
            'memory_mb': test_df.memory_usage(deep=True).sum() / (1024**2),
            'missing_cells': test_df.isnull().sum().sum(),
            'missing_percentage': (test_df.isnull().sum().sum() / (test_df.shape[0] * test_df.shape[1])) * 100
        },
        'column_types': {
            'quantitative': quantitative_present,
            'binary': binary_cols,
            'categorical': categorical_cols,
            'target_column': target_col,
            'total_binary': len(binary_cols)
        }
    }
    
    # Analyse de la variable cible
    if target_col and target_col in train_df.columns:
        target_counts = train_df[target_col].value_counts()
        summary['target_distribution'] = {
            'counts': target_counts.to_dict(),
            'percentages': (target_counts / len(train_df) * 100).to_dict()
        }
        
        if len(target_counts) == 2:
            majority = target_counts.max()
            minority = target_counts.min()
            summary['target_distribution']['imbalance_ratio'] = majority / minority
    
    # Analyse des variables quantitatives X1, X2, X3
    summary['quantitative_analysis'] = {}
    for var in quantitative_present:
        if var in train_df.columns:
            var_data = train_df[var].dropna()
            display_name = f"{var} ({COLUMN_MAPPING.get(var, var)})"
            
            summary['quantitative_analysis'][display_name] = {
                'column_name': var,
                'missing_count': train_df[var].isnull().sum(),
                'missing_percentage': (train_df[var].isnull().sum() / len(train_df)) * 100,
                'zero_count': (train_df[var] == 0).sum(),
                'zero_percentage': ((train_df[var] == 0).sum() / len(train_df)) * 100,
                'min': var_data.min() if len(var_data) > 0 else None,
                'max': var_data.max() if len(var_data) > 0 else None,
                'mean': var_data.mean() if len(var_data) > 0 else None,
                'median': var_data.median() if len(var_data) > 0 else None
            }
    
    # Analyse des variables binaires (échantillon)
    summary['binary_analysis'] = {}
    for var in binary_cols[:5]:  # Limité aux 5 premières pour l'affichage
        if var in train_df.columns:
            var_data = train_df[var].dropna()
            summary['binary_analysis'][var] = {
                'missing_count': train_df[var].isnull().sum(),
                'missing_percentage': (train_df[var].isnull().sum() / len(train_df)) * 100,
                'ones_count': (train_df[var] == 1).sum(),
                'ones_percentage': ((train_df[var] == 1).sum() / len(train_df)) * 100,
                'unique_values': sorted(var_data.unique()) if len(var_data) > 0 else []
            }
    
    return summary

def display_loading_report(train_df: pd.DataFrame, test_df: pd.DataFrame) -> None:
    """Affiche un rapport détaillé du chargement des données"""
    
    summary = get_data_summary(train_df, test_df)
    
    print("📊 RAPPORT DE CHARGEMENT - INTERNET ADVERTISEMENTS")
    print("=" * 55)
    
    # Informations générales
    print(f"\n📋 Informations générales:")
    print(f"  • Train: {summary['train']['shape'][0]:,} × {summary['train']['shape'][1]:,}")
    print(f"  • Test:  {summary['test']['shape'][0]:,} × {summary['test']['shape'][1]:,}")
    print(f"  • Mémoire totale: {summary['train']['memory_mb'] + summary['test']['memory_mb']:.1f} MB")
    
    # Structure des variables
    print(f"\n📊 Structure des variables:")
    quant_cols = summary['column_types']['quantitative']
    binary_count = summary['column_types']['total_binary']
    cat_cols = summary['column_types']['categorical']
    
    print(f"  • Variables quantitatives (X1-X3): {len(quant_cols)} ({', '.join(quant_cols)})")
    print(f"  • Variables binaires (X4+): {binary_count} colonnes")
    if binary_count > 0:
        first_few = summary['column_types']['binary'][:5]
        print(f"    └─ Premières: {', '.join(first_few)}{'...' if binary_count > 5 else ''}")
    print(f"  • Variables catégorielles: {len(cat_cols)} ({', '.join(cat_cols) if cat_cols else 'aucune'})")
    
    if summary['column_types']['target_column']:
        print(f"  • Variable cible: {summary['column_types']['target_column']}")
    
    # Variable cible
    if 'target_distribution' in summary:
        target_col = summary['column_types']['target_column']
        print(f"\n🎯 Distribution de la variable cible ({target_col}):")
        for class_name, percentage in summary['target_distribution']['percentages'].items():
            count = summary['target_distribution']['counts'][class_name]
            print(f"  • {class_name}: {count:,} ({percentage:.2f}%)")
        
        if 'imbalance_ratio' in summary['target_distribution']:
            ratio = summary['target_distribution']['imbalance_ratio']
            print(f"  ⚖️ Ratio de déséquilibre: {ratio:.1f}:1")
    
    # Valeurs manquantes
    print(f"\n❓ Valeurs manquantes:")
    print(f"  • Train: {summary['train']['missing_cells']:,} ({summary['train']['missing_percentage']:.2f}%)")
    print(f"  • Test:  {summary['test']['missing_cells']:,} ({summary['test']['missing_percentage']:.2f}%)")
    
    # Variables quantitatives détaillées
    if summary['quantitative_analysis']:
        print(f"\n📊 Variables quantitatives (X1, X2, X3):")
        for display_name, stats in summary['quantitative_analysis'].items():
            print(f"  • {display_name}:")
            print(f"    - Valeurs manquantes: {stats['missing_percentage']:.1f}%")
            print(f"    - Valeurs nulles: {stats['zero_percentage']:.1f}%")
            if stats['min'] is not None:
                print(f"    - Intervalle: [{stats['min']:.3f}, {stats['max']:.3f}]")
                print(f"    - Moyenne: {stats['mean']:.3f}, Médiane: {stats['median']:.3f}")
    
    # Variables binaires (aperçu)
    if summary['binary_analysis']:
        print(f"\n🔢 Variables binaires (aperçu des premières):")
        for var, stats in summary['binary_analysis'].items():
            print(f"  • {var}:")
            print(f"    - Valeurs manquantes: {stats['missing_percentage']:.1f}%")
            print(f"    - Présence (1): {stats['ones_percentage']:.1f}%")
            print(f"    - Valeurs uniques: {stats['unique_values']}")

def load_internet_advertisements(data_dir: Path, random_state: int = 42,
                                train_filename: str = "data_train.csv",
                                test_filename: str = "data_test.csv") -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Fonction principale pour charger les données Internet Advertisements
    
    Parameters:
    -----------
    data_dir : Path
        Répertoire contenant les fichiers de données
    random_state : int
        Graine aléatoire pour la reproductibilité
    train_filename : str
        Nom du fichier d'entraînement
    test_filename : str
        Nom du fichier de test
        
    Returns:
    --------
    Tuple[pd.DataFrame, pd.DataFrame]
        (train_df, test_df) - DataFrames chargés avec rapport affiché
    """
    
    # Configuration du random state
    np.random.seed(random_state)
    
    # Chargement des données
    train_df, test_df = load_raw_datasets(data_dir, train_filename, test_filename)
    
    # Affichage du rapport
    display_loading_report(train_df, test_df)
    
    return train_df, test_df

def get_quantitative_columns():
    """Retourne la liste des colonnes quantitatives avec leur signification"""
    return {col: COLUMN_MAPPING[col] for col in QUANTITATIVE_COLS}

def get_binary_columns(df: pd.DataFrame) -> List[str]:
    """Retourne la liste des colonnes binaires (X4, X5, X6...)"""
    binary_cols = [col for col in df.columns 
                   if col.startswith('X') and col not in QUANTITATIVE_COLS]
    binary_cols.sort(key=lambda x: int(x[1:]) if x[1:].isdigit() else float('inf'))
    return binary_cols

def get_target_column():
    """Retourne le nom de la variable cible"""
    return TARGET_COL

# Test du module si exécuté directement
if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO)
    
    test_data_dir = Path("../data/raw")
    if test_data_dir.exists():
        try:
            train, test = load_internet_advertisements(test_data_dir)
            print(f"✅ Test réussi - Train: {train.shape}, Test: {test.shape}")
            
            # Test des fonctions utilitaires
            quant_cols = get_quantitative_columns()
            binary_cols = get_binary_columns(train)
            target_col = get_target_column()
            print(f"📊 Quantitatives: {quant_cols}")
            print(f"🔢 Binaires: {len(binary_cols)} colonnes")
            print(f"🎯 Target: {target_col}")
            
        except Exception as e:
            print(f"❌ Test échoué: {e}")
    else:
        print(f"⚠️ Répertoire de test non trouvé: {test_data_dir}")