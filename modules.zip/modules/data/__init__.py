#__init__.py

"""
Package de gestion des données pour le projet STA211

Ce package contient tous les modules liés au chargement, 
validation et manipulation des données.

Structure des données:
- X1, X2, X3: Variables quantitatives 
- X4, X5, X6, ...: Variables binaires (0/1)
- ad.: Variable cible
"""

from .loader import (
    load_internet_advertisements,
    load_raw_datasets,
    get_data_summary,
    display_loading_report,
    validate_files_exist,
    validate_loaded_data,
    get_quantitative_columns
)

# Export des constantes utiles (sans BINARY_COLS qui n'existe plus)
from .loader import (
    QUANTITATIVE_COLS,
    TARGET_COL
)

__all__ = [
    # Fonction principale
    'load_internet_advertisements',
    
    # Fonctions utilitaires
    'load_raw_datasets',
    'get_data_summary', 
    'display_loading_report',
    'validate_files_exist',
    'validate_loaded_data',
    'get_quantitative_columns',
    
    # Constantes
    'QUANTITATIVE_COLS',
    'TARGET_COL'
]

__version__ = "1.0.0"
__author__ = "Abdoullatuf"