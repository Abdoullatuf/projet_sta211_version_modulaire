#modules/modeling/ablation_analysis.py

from sklearn.metrics import f1_score
from sklearn.base import clone
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SMOTE
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import joblib
import seaborn as sns
import json
from pathlib import Path
from sklearn.inspection import permutation_importance
from IPython.display import Markdown, display

def run_ablation_analysis(
    model,
    X_train,
    y_train,
    X_test,
    y_test,
    feature_importance,
    threshold,
    n_features_range,
    model_name,
    dataset_name,
    save_path,
    apply_smote=False,
    best_params=None,
    random_state=None
):
    """
    Étudie l'impact du nombre de variables sur la performance (F1-score).
    """
    print(f"🧪 Étude d'ablation sur {dataset_name} ({model_name})")

    if n_features_range is None:
        n_features_range = list(range(5, min(X_train.shape[1], 105), 5))

    f1_scores = []
    used_features = []

    for n in n_features_range:
        n_int = int(n)
        top_features = feature_importance["Variable"].head(n_int).tolist()

        X_train_sel = X_train[top_features]
        X_test_sel = X_test[top_features]

        steps = []
        if apply_smote:
            steps.append(('smote', SMOTE(random_state=random_state)))
        model_clone = clone(model)
        if best_params:
            model_clone.set_params(**best_params)
        steps.append(('classifier', model_clone))
        pipeline = ImbPipeline(steps)

        pipeline.fit(X_train_sel, y_train)
        y_pred = pipeline.predict(X_test_sel)
        score = f1_score(y_test, y_pred)
        f1_scores.append(score)
        used_features.append(top_features)

        print(f" → {n_int} variables : F1 = {score:.4f}")

    ablation_df = pd.DataFrame({
        "N_Variables": n_features_range,
        "F1_score": f1_scores
    })

    best_idx = np.argmax(f1_scores)
    best_n = int(n_features_range[best_idx])
    best_f1 = f1_scores[best_idx]
    best_features = used_features[best_idx]

    print(f"\n✅ Meilleur score F1 : {best_f1:.4f} avec {best_n} variables.")

    # === Visualisation
    plt.figure(figsize=(8, 5))
    plt.plot(n_features_range, f1_scores, 'o-', color='teal')
    plt.axvline(best_n, linestyle="--", color="red", label=f"N optimal = {best_n}\nF1 = {best_f1:.4f}")
    plt.title(f"Ablation - {model_name} ({dataset_name})")
    plt.xlabel("Nombre de variables utilisées")
    plt.ylabel("F1-score")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()

    if save_path:
        fig_name = f"ablation_{model_name.lower().replace(' ', '_')}_" \
                   f"{dataset_name.lower().replace(' ', '_')}.png"
        plt.savefig(save_path / fig_name)
        print(f"📁 Figure sauvegardée : {save_path / fig_name}")
    plt.show()

    return ablation_df, best_n, best_f1, best_features

def find_optimal_threshold(y_true, y_proba):
    """
    Trouve le seuil optimal pour maximiser le F1-score.
    
    Args:
        y_true: Vraies valeurs
        y_proba: Probabilités prédites (classe positive)
    
    Returns:
        tuple: (seuil_optimal, f1_score_optimal)
    """
    thresholds = np.arange(0.2, 0.8, 0.01)
    f1_scores = [f1_score(y_true, y_proba >= t) for t in thresholds]
    best_idx = np.argmax(f1_scores)
    return thresholds[best_idx], f1_scores[best_idx]

def retrain_and_evaluate_ablation(base_model, best_params, X_train, y_train, X_test, y_test):
    """
    Ré-entraîne un modèle cloné avec des paramètres fixes et l'évalue.
    
    Args:
        base_model: Modèle de base à cloner
        best_params: Meilleurs hyperparamètres (dict)
        X_train, y_train: Données d'entraînement
        X_test, y_test: Données de test
    
    Returns:
        tuple: (f1_score, seuil_optimal, modèle_entraîné)
    """
    # Cloner le pipeline pour ne pas modifier l'original
    model_to_train = clone(base_model)
    
    # Appliquer les meilleurs hyperparamètres trouvés précédemment
    model_to_train.set_params(**best_params)
    
    # Entraînement sur le jeu de données (potentiellement réduit)
    model_to_train.fit(X_train, y_train)
    
    # Évaluation
    y_pred_proba = model_to_train.predict_proba(X_test)[:, 1]
    optimal_threshold, _ = find_optimal_threshold(y_test, y_pred_proba)
    f1 = f1_score(y_test, y_pred_proba >= optimal_threshold)
    
    return f1, optimal_threshold, model_to_train

def load_stacking_artifacts(models_dir, dataset_name):
    """
    Charge tous les artefacts nécessaires pour l'analyse d'ablation.
    
    Args:
        models_dir: Répertoire des modèles
        dataset_name: Nom du dataset ('knn' ou 'mice')
    
    Returns:
        dict: Dictionnaire contenant tous les artefacts
    """
    prefix = f"model_final_{dataset_name}"
    
    # Chargement des fichiers
    comparison_df = pd.read_csv(models_dir / f"{prefix}_stacking_comparison.csv")
    importance_df = pd.read_csv(models_dir / f"{prefix}_stacking_perm_importance.csv")
    model = joblib.load(models_dir / f"{prefix}_stacking_best_model.joblib")
    
    # Parsing des hyperparamètres
    best_params = json.loads(comparison_df.loc[0, 'Best Params'])
    
    return {
        'comparison_df': comparison_df,
        'importance_df': importance_df,
        'model': model,
        'best_params': best_params
    }

def perform_ablation_study(X_train, y_train, X_test, y_test, 
                          importance_df, best_params, base_model,
                          n_features_list=None, save_dir=None):
    """
    Effectue une étude d'ablation complète.
    
    Args:
        X_train, y_train, X_test, y_test: Données
        importance_df: DataFrame d'importance des variables
        best_params: Meilleurs hyperparamètres
        base_model: Modèle de base
        n_features_list: Liste des nombres de variables à tester
        save_dir: Répertoire de sauvegarde
    
    Returns:
        dict: Résultats de l'ablation
    """
    if n_features_list is None:
        n_features_list = [50, 100, 200, 300, 400, 500]
    
    results = []
    
    for n_features in n_features_list:
        if n_features > len(importance_df):
            continue
            
        # Sélection des variables les plus importantes
        top_features = importance_df['Variable'].head(n_features).tolist()
        
        # Vérification que toutes les variables sont présentes
        available_features = [f for f in top_features if f in X_train.columns]
        if len(available_features) != len(top_features):
            print(f"⚠️ Attention: {len(top_features) - len(available_features)} variables manquantes pour {n_features} features")
        
        # Ré-entraînement et évaluation
        f1_score_ablation, optimal_threshold, _ = retrain_and_evaluate_ablation(
            base_model=base_model,
            best_params=best_params,
            X_train=X_train[available_features],
            y_train=y_train,
            X_test=X_test[available_features],
            y_test=y_test
        )
        
        results.append({
            'n_features': len(available_features),
            'f1_score': f1_score_ablation,
            'optimal_threshold': optimal_threshold,
            'features': available_features
        })
        
        print(f"📊 {len(available_features)} variables → F1 = {f1_score_ablation:.4f} (seuil = {optimal_threshold:.2f})")
    
    return results

def plot_ablation_results(ablation_results, reference_f1=None, save_path=None):
    """
    Visualise les résultats de l'étude d'ablation.
    
    Args:
        ablation_results: Résultats de l'ablation
        reference_f1: F1-score de référence (toutes variables)
        save_path: Chemin de sauvegarde
    """
    df_results = pd.DataFrame(ablation_results)
    
    plt.figure(figsize=(10, 6))
    
    # Courbe principale
    plt.plot(df_results['n_features'], df_results['f1_score'], 
             marker='o', linewidth=2, markersize=8, label='Ablation')
    
    # Ligne de référence si fournie
    if reference_f1 is not None:
        plt.axhline(y=reference_f1, color='red', linestyle='--', 
                   alpha=0.7, label=f'Référence (toutes variables): {reference_f1:.4f}')
    
    # Mise en forme
    plt.xlabel('Nombre de variables')
    plt.ylabel('F1-score (seuil optimisé)')
    plt.title('Étude d\'ablation : Performance F1 vs nombre de variables')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Sauvegarde
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    plt.show()
    
    return df_results

def ablation_analysis_pipeline(X_train, y_train, X_test, y_test, 
                              models_dir, dataset_name, 
                              n_features_list=None, save_dir=None):
    """
    Pipeline complet d'analyse d'ablation.
    
    Args:
        X_train, y_train, X_test, y_test: Données
        models_dir: Répertoire des modèles
        dataset_name: Nom du dataset
        n_features_list: Liste des nombres de variables à tester
        save_dir: Répertoire de sauvegarde
    
    Returns:
        dict: Résultats complets
    """
    print(f"🔍 Analyse d'ablation pour {dataset_name.upper()}")
    print("=" * 50)
    
    # Chargement des artefacts
    artifacts = load_stacking_artifacts(models_dir, dataset_name)
    
    # F1-score de référence
    reference_f1 = artifacts['comparison_df'].loc[0, 'F1-score (seuil optimisé)']
    print(f"📌 F1-score de référence (toutes variables): {reference_f1:.4f}")
    
    # Étude d'ablation
    ablation_results = perform_ablation_study(
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        importance_df=artifacts['importance_df'],
        best_params=artifacts['best_params'],
        base_model=artifacts['model'],
        n_features_list=n_features_list
    )
    
    # Visualisation
    if save_dir:
        save_path = save_dir / f"ablation_study_{dataset_name}.png"
    else:
        save_path = None
    
    df_results = plot_ablation_results(
        ablation_results=ablation_results,
        reference_f1=reference_f1,
        save_path=save_path
    )
    
    # Résumé
    print("\n📋 Résumé de l'ablation:")
    print(f"- Meilleur F1 avec ablation: {df_results['f1_score'].max():.4f}")
    print(f"- Nombre optimal de variables: {df_results.loc[df_results['f1_score'].idxmax(), 'n_features']}")
    
    return {
        'artifacts': artifacts,
        'ablation_results': ablation_results,
        'df_results': df_results,
        'reference_f1': reference_f1
    }
