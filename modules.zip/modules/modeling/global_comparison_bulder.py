import pandas as pd
from IPython.display import Markdown, display

def build_global_comparison_table(results_comparison, comparison_df_knn, comparison_df_mice):
    """
    Construit et affiche un tableau comparatif global entre les modèles classiques et les modèles de stacking.

    Parameters
    ----------
    results_comparison : pd.DataFrame
        Tableau des scores des modèles classiques.
    comparison_df_knn : pd.DataFrame
        Tableau des scores du modèle stacking avec données KNN.
    comparison_df_mice : pd.DataFrame
        Tableau des scores du modèle stacking avec données MICE.

    Returns
    -------
    df_global_sorted : pd.DataFrame
        Le tableau final trié par F1-score.
    """
    # Concaténation des résultats stacking
    stacking_comparison_df = pd.concat([comparison_df_knn, comparison_df_mice], ignore_index=True)
    stacking_comparison_df = stacking_comparison_df.rename(columns={"F1-score": "F1-score (binary)"})

    # Fusion complète
    df_global = pd.concat([results_comparison, stacking_comparison_df], ignore_index=True)
    df_global_sorted = df_global.sort_values(by="F1-score (binary)", ascending=False)

    # Affichage
    display(Markdown("### 📊 COMPARAISON GLOBALE : CLASSIQUE VS STACKING"))
    display(df_global_sorted.style.highlight_max(subset=["F1-score (binary)"]))

    return df_global_sorted
