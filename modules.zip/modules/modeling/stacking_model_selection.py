#modules/modeling/stacking_model_selection.py (version optimisée)
from typing import Tuple, Union
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (f1_score, precision_score, recall_score,
                             roc_auc_score, classification_report)
from sklearn.base import clone
from imblearn.over_sampling import BorderlineSMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from skopt import BayesSearchCV
from skopt.space import Real, Integer
import pandas as pd
import numpy as np
import joblib
import json
from pathlib import Path

# Patch de compatibilité pour numpy >= 1.20
if not hasattr(np, 'int'):
    np.int = int

def define_stacking_pipeline(
    random_state: int = 42,
    use_scaler: bool = True,
    use_smote: bool = True
) -> ImbPipeline:
    """
    Construit un pipeline de stacking avec :
    - estimateurs de base : Random Forest, SVM, XGBoost, CatBoost
    - estimateur final : régression logistique
    - standardisation et SMOTE optionnels
    """
    base_learners = [
        ("rf", RandomForestClassifier(random_state=random_state)),
        ("svm", SVC(probability=True, random_state=random_state)),
        ("xgb", XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=random_state)),
        ("catboost", CatBoostClassifier(verbose=0, random_state=random_state))
    ]

    final_estimator = LogisticRegression(solver='lbfgs', max_iter=1000, random_state=random_state)

    stack_model = StackingClassifier(
        estimators=base_learners,
        final_estimator=final_estimator,
        passthrough=True,
        cv=5,
        n_jobs=-1
    )

    steps = []
    if use_scaler:
        steps.append(("scaler", StandardScaler()))
    if use_smote:
        steps.append(("smote", BorderlineSMOTE(random_state=random_state)))
    steps.append(("stacking", stack_model))

    return ImbPipeline(steps)


def search_stacking_hyperparameters(
    pipeline: ImbPipeline,
    X: pd.DataFrame,
    y: pd.Series,
    scoring: str,
    n_iter: int,
    random_state: int
) -> BayesSearchCV:
    """
    Effectue une recherche bayésienne sur les hyperparamètres du modèle de stacking.
    Retourne l'objet BayesSearchCV entraîné.
    """
    param_space = {
        'stacking__final_estimator__C': Real(1e-3, 10, prior='log-uniform'),
        'stacking__rf__n_estimators': Integer(100, 300),
        'stacking__rf__max_depth': Integer(3, 15),
        'stacking__svm__C': Real(1e-2, 10, prior='log-uniform'),
        'stacking__xgb__n_estimators': Integer(50, 200),
        'stacking__xgb__max_depth': Integer(3, 10),
        'stacking__xgb__learning_rate': Real(0.01, 0.3, prior='log-uniform'),
        'stacking__xgb__min_child_weight': Integer(1, 10)
    }

    bayes_search = BayesSearchCV(
        estimator=pipeline,
        search_spaces=param_space,
        n_iter=n_iter,
        scoring=scoring,
        cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state),
        verbose=0,
        n_jobs=-1,
        random_state=random_state
    )
    bayes_search.fit(X, y)
    return bayes_search


def evaluate_thresholds(
    model: Pipeline,
    X_test: pd.DataFrame,
    y_test: pd.Series
) -> Tuple[pd.DataFrame, float]:
    """
    Évalue la performance du modèle selon différents seuils.
    Retourne :
    - un DataFrame avec F1, précision, rappel et AUC selon le seuil
    - le seuil optimal pour le F1-score
    """
    y_probs = model.predict_proba(X_test)[:, 1]
    thresholds = np.linspace(0.1, 0.9, 81)
    results = []

    for threshold in thresholds:
        y_pred = (y_probs >= threshold).astype(int)
        results.append({
            "Threshold": threshold,
            "F1-score": f1_score(y_test, y_pred),
            "Precision": precision_score(y_test, y_pred),
            "Recall": recall_score(y_test, y_pred),
            "AUC": roc_auc_score(y_test, y_probs)
        })

    df = pd.DataFrame(results).sort_values(by="F1-score", ascending=False)
    return df, df.iloc[0]["Threshold"]


def train_and_select_best_stacking_model(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    save_dir: Union[str, Path],
    prefix: str = "model_final",
    scoring: str = "f1",
    n_iter: int = 50,
    random_state: int = 42,
    use_scaler: bool = True,
    use_smote: bool = True
) -> Tuple[Pipeline, pd.DataFrame, float]:
    """
    Entraîne un modèle de stacking optimisé via BayesSearchCV, ajuste le seuil optimal,
    et sauvegarde le modèle, les résultats et le rapport de classification.
    """
    print(f"🚀 Démarrage de l'entraînement stacking avec {prefix}")
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)

    pipeline = define_stacking_pipeline(random_state, use_scaler, use_smote)
    bayes_search = search_stacking_hyperparameters(pipeline, X_train, y_train, scoring, n_iter, random_state)
    best_model = bayes_search.best_estimator_

    comparison_df, optimal_threshold = evaluate_thresholds(best_model, X_test, y_test)

    joblib.dump(best_model, save_dir / f"{prefix}_stacking_best_model.joblib")
    comparison_df.to_csv(save_dir / f"{prefix}_stacking_comparison.csv", index=False)

    y_pred_opt = (best_model.predict_proba(X_test)[:, 1] >= optimal_threshold).astype(int)
    report = classification_report(y_test, y_pred_opt, output_dict=True)
    with open(save_dir / f"{prefix}_stacking_classification_report.json", "w") as f:
        json.dump(report, f, indent=4)

    print(f"✅ Modèle sauvegardé ({prefix}) | Seuil optimal F1 = {optimal_threshold:.4f}")
    return best_model, comparison_df, optimal_threshold

