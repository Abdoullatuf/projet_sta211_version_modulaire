# 🧠 Projet STA211 — Détection de Publicités dans les Images

Ce projet a été réalisé dans le cadre du cours **STA211** du **CNAM**. L'objectif est de construire un pipeline de machine learning complet pour résoudre un problème de classification binaire : déterminer si une image est une publicité (`ad.`) ou non (`noad.`).

Ce dépôt contient l'ensemble du code, de l'analyse exploratoire à la modélisation, en passant par le prétraitement des données, en s'appuyant sur le jeu de données **Internet Advertisements Dataset** de l'UCI.

## Table des matières
- [Installation](#installation)
- [Jeu de données](#jeu-de-données)
- [Structure du dépôt](#structure-du-dépôt)
- [Utilisation](#utilisation)
- [Lancer les tests](#lancer-les-tests)
- [Licence](#licence)

## Installation

1.  Assurez-vous d'avoir **Python 3.11** ou une version plus récente.
2.  Clonez le dépôt et créez un environnement virtuel :
    ```bash
    git clone <url-du-repo>
    cd projet_sta211
    python -m venv venv_sta211
    source venv_sta211/bin/activate  # Sur Windows: venv_sta211\Scripts\activate
    ```
3.  Installez les dépendances requises :
    ```bash
    pip install -r requirements_sta211.txt
    ```

## Jeu de données

Le projet utilise le **Internet Advertisements Dataset** disponible sur le [UCI Machine Learning Repository](https://archive.ics.uci.edu/ml/datasets/internet+advertisements).

Avant de lancer les scripts, téléchargez les fichiers `ad.data` et `ad.names` et placez-les dans le dossier `data/raw/`.

## Structure du dépôt

Le projet est organisé de manière modulaire pour séparer clairement les différentes étapes du pipeline de data science.

```
projet_sta211/
│
├── modules/              # Code source modulaire du projet
│   ├── config/           # Modules de configuration (chemins, variables)
│   ├── exploration/      # Scripts pour l'analyse exploratoire (EDA)
│   ├── modeling/         # Scripts pour l'entraînement, l'évaluation et l'optimisation des modèles
│   ├── preprocessing/    # Scripts pour le nettoyage et la préparation des données
│   └── utils/            # Fonctions utilitaires (logs, helpers)
│
├── notebooks/            # Notebooks Jupyter pour l'expérimentation et la présentation
│
├── data/                 # Données du projet
│   ├── raw/              # Données brutes originales
│   └── processed/        # Données nettoyées et prétraitées
│
├── outputs/              # Fichiers générés par les scripts
│   ├── figures/          # Graphiques et visualisations
│   ├── metadata/         # Métadonnées sur les exécutions
│   ├── modeling/         # Modèles sauvegardés, métriques, etc.
│   └── submissions/      # Fichiers de soumission pour la compétition
│
├── tests/                # Scripts de tests pour valider le pipeline
│
├── requirements_sta211.txt # Fichier listant les dépendances Python
└── README.md             # Ce fichier
```

## Utilisation

L'exploration des données et la modélisation sont principalement menées à travers les notebooks Jupyter situés dans le dossier `/notebooks`.

1.  **`01_EDA_Preprocessing_v_modulaire.ipynb`**: Contient l'analyse exploratoire des données et les étapes de prétraitement.
2.  **`02_Modelisation_Optimisation_v_modulaire.ipynb`**: Contient la construction, l'entraînement et l'évaluation des modèles de classification.

Pour exécuter un pipeline de test de base, vous pouvez utiliser le script dans le dossier `tests/`.

## Lancer les tests

Des tests peuvent être ajoutés pour vérifier l'intégrité du pipeline. Si `pytest` est configuré, ils peuvent être lancés avec :

```bash
pytest
```

## Licence

Ce projet est distribué sous la licence MIT. Voir le fichier `LICENSE` pour plus de détails.