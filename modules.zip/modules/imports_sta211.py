"""
Module d'import centralisé pour le projet STA 211.
Toutes les bibliothèques courantes sont pré-configurées pour un usage
« notebook » ou script ; un simple
    from imports_sta211 import *
suffit ensuite.

Mise à jour : suppression de LightGBM.
"""

# ============================================================================
# BIBLIOTHÈQUES STANDARD
# ============================================================================
import os
import sys
import warnings
import logging
from pathlib import Path
from typing import List, Tuple, Optional, Union

# ============================================================================
# LOGGING GLOBAL
# ============================================================================
logger = logging.getLogger(__name__)

# ============================================================================
# DATA & NUMPY STACK
# ============================================================================
import pandas as pd
import numpy as np

# ============================================================================
# VISUALISATION
# ============================================================================
import matplotlib            # <-- pour matplotlib.__version__
import matplotlib.pyplot as plt
import seaborn as sns

# ============================================================================
# MACHINE LEARNING – SCIKIT-LEARN
# ============================================================================
from catboost import CatBoostClassifier
from imblearn.over_sampling import BorderlineSMOTE
import sklearn               # <-- pour sklearn.__version__
from sklearn.model_selection import (
    StratifiedKFold,
    GridSearchCV,
    RandomizedSearchCV,
)
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    accuracy_score,
    precision_score,
    recall_score,
    make_scorer,
)

# ============================================================================
# IMBALANCED-LEARN
# ============================================================================
import imblearn              # <-- pour imblearn.__version__
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SMOTE

# ============================================================================
# GRADIENT BOOSTING – XGBoost uniquement
# ============================================================================
import xgboost as xgb
from xgboost import XGBClassifier

# ============================================================================
# NUMERICAL & SCIENCE UTILS
# ============================================================================
import scipy                 # <-- pour scipy.__version__
import joblib                # <-- pour joblib.__version__

# ============================================================================
# PROGRESS BARS
# ============================================================================
from tqdm.auto import tqdm

# ============================================================================
# CONFIG GRAPHIQUE
# ============================================================================
plt.style.use("seaborn-v0_8-whitegrid")
plt.rcParams.update(
    {
        "figure.figsize": (10, 6),
        "font.size": 10,
        "axes.labelsize": 12,
        "axes.titlesize": 14,
        "legend.fontsize": 10,
        "figure.dpi": 100,
    }
)
sns.set_palette("husl")
sns.set_context("notebook")

# ============================================================================
# OPTIONS D’AFFICHAGE PANDAS
# ============================================================================
pd.set_option("display.max_columns", None)
pd.set_option("display.max_rows", 100)
pd.set_option("display.width", 1000)
pd.set_option("display.float_format", "{:.4f}".format)

# ============================================================================
# WARNINGS
# ============================================================================
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
from sklearn.exceptions import ConvergenceWarning, FitFailedWarning

warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=FitFailedWarning)

# ============================================================================
# RNG SEED GLOBAL & VALIDATION CONFIG
# ============================================================================
RANDOM_STATE: int = 42
N_SPLITS: int = 5

np.random.seed(RANDOM_STATE)

# ============================================================================
# FONCTIONS UTILITAIRES
# ============================================================================
def print_shape_change(df_before: pd.DataFrame, df_after: pd.DataFrame, operation: str) -> None:
    """Affiche le changement de dimensions après une opération de pré-traitement."""
    print(f"\n{operation}:")
    print(f"  Avant : {df_before.shape}")
    print(f"  Après : {df_after.shape}")
    print(f"  Lignes supprimées : {df_before.shape[0] - df_after.shape[0]}")
