#modules/modeling/generation_submission.py


# 10. Génération des prédictions finales <a name="10-génération-des-prédictions-finales"></a>

import pandas as pd
import joblib
import numpy as np
from pathlib import Path
from preprocessing.final_preprocessing import prepare_final_dataset
from modeling.optimize_threshold import load_optimal_threshold

def generate_submission_final_pipeline(
    test_file,
    model_file,
    features_file,
    threshold_dir,
    output_path,
    model_name="stacking",
    dataset_name="mice",
    imputation_method="mice",
    yeojohnson=True,
    remove_outliers=False,
    verbose=True
):
    """
    Génère les prédictions finales pour le challenge STA211 à partir de `data_test.csv`.
    """

    if verbose:
        print("📥 Chargement du fichier test brut...")

    test_file = Path(test_file)

    # 1. Pipeline complet de prétraitement
    if verbose:
        print("⚙️ Application du pipeline de prétraitement...")

    df_test = prepare_final_dataset(
        file_path=test_file,
        strategy='mixed_mar_mcar',
        mar_method=imputation_method,
        drop_outliers=remove_outliers,
        display_info=verbose,
        require_outcome=False,
        save_transformer=False,
        use_comprehensive_correlation=True
    )

    # 2. Chargement des variables sélectionnées
    if verbose:
        print("📌 Chargement des variables sélectionnées...")
    selected_features = joblib.load(features_file)
    X_test = df_test[selected_features]

    # 3. Chargement du modèle entraîné
    if verbose:
        print("🤖 Chargement du modèle...")
    model = joblib.load(model_file)

    # 4. Chargement du seuil optimal (corrigé ici)
    if verbose:
        print(f"🎯 Chargement du seuil optimal depuis : {threshold_dir}")
    optimal_threshold = load_optimal_threshold(
        model_name=model_name,
        dataset_name=dataset_name,
        threshold_dir=threshold_dir
    )
    if optimal_threshold is None:
        raise ValueError("❌ Seuil optimal introuvable.")

    # 5. Prédictions et application du seuil
    y_probs = model.predict_proba(X_test)[:, 1]
    y_pred = (y_probs >= optimal_threshold).astype(int)
    labels = pd.Series(y_pred).map({0: "noad.", 1: "ad."})

    # 6. Sauvegarde du fichier de soumission
    submission_df = pd.DataFrame({
        "id": df_test.index + 1,
        "label": labels
    })

    output_path = Path(output_path)
    submission_df.to_csv(output_path, index=False)

    if verbose:
        print(f"✅ Fichier de soumission enregistré à : {output_path}")
        print("🧾 Aperçu :")
        display(submission_df.head())

    return submission_df

