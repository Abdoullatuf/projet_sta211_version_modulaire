"""
Initialisation complète du projet STA211 (local ou Google Colab).
"""

from __future__ import annotations

import os, sys, logging, warnings
from pathlib import Path
from subprocess import run as _run, CalledProcessError
import inspect

import pandas as pd
import IPython

# SUGGESTION : Importer 'is_colab' pour centraliser la logique de détection.
from .paths_config import setup_project_paths, is_colab
from .project_config import create_config, ProjectConfig
from .display_config import set_display_options

__all__ = ["init_project"]

# ──────────────────────── LOGGER ────────────────────────
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(levelname)s - %(message)s",
                    stream=sys.stdout,
                    force=True)
log = logging.getLogger(__name__)

# ──────────────────────── UTILS ────────────────────────

def _mount_drive_if_needed():
    if is_colab():
        from google.colab import drive  # type: ignore
        log.info("🔗 Montage de Google Drive en cours…")
        drive.mount("/content/drive", force_remount=False)

def _get_root_dir() -> Path:
    """Détermine la racine du projet en fonction de l'environnement."""
    env_root = os.getenv("STA211_PROJECT_PATH")
    if env_root and (Path(env_root) / "modules").exists():
        return Path(env_root).expanduser().resolve()

    if is_colab():
        default_colab = Path("/content/drive/MyDrive/projet_sta211")
        if (default_colab / "modules").exists():
            return default_colab.resolve()

    cwd = Path.cwd()
    for p in [cwd, *cwd.parents]:
        if (p / "modules").exists():
            return p.resolve()

    raise FileNotFoundError("❌ Impossible de localiser un dossier contenant 'modules/'.")

def _install_if_needed(req: Path, sentinel: str = "catboost"):
    """Installe les dépendances depuis un fichier requirements_sta211.txt si nécessaire."""
    import importlib.util
    if importlib.util.find_spec(sentinel) is None and req.exists():
        log.info(f"📦 Installation des dépendances depuis {req.name}…")
        try:
            _run([sys.executable, "-m", "pip", "install", "-q", "-r", str(req)], check=True)
            log.info(f"✅ Installation réussie.")
        except CalledProcessError as e:
            log.error(f"❌ Erreur lors de l'installation : {e}")
            raise

def display_paths(paths, style: bool = True):
    """Affiche les chemins utiles dans un DataFrame stylisé."""
    rows = [{"Clé": k, "Chemin": os.fspath(v)} for k, v in paths.items() if "DIR" in k]
    df = pd.DataFrame(rows).set_index("Clé")
    from IPython.display import display
    display(df.style.set_table_styles([
        {"selector": "th", "props": [("text-align", "left")]},
        {"selector": "td", "props": [("text-align", "left")]},
    ]) if style else df)

# ──────────────────────── INIT PRINCIPALE ────────────────────────
def init_project(extra_libs: tuple[str, ...] = ("numpy", "sklearn", "xgboost", "imblearn", "catboost")) -> dict:
    """
    Initialise dynamiquement le projet STA211 (Colab ou local) et retourne les paramètres clés.

    Args:
        extra_libs (tuple): Bibliothèques à vérifier pour les versions (défaut: numpy, sklearn, xgboost, imblearn, catboost).

    Returns:
        dict: Configuration du projet incluant chemins, versions, etc.
    """
    warnings.filterwarnings("ignore")
    env = "colab" if is_colab() else "local"
    log.info(f"🧭 Environnement détecté : {env}")

    _mount_drive_if_needed()

    root = _get_root_dir()
    os.environ["STA211_PROJECT_PATH"] = str(root)
    module_dir = root / "modules"
    if str(module_dir) not in sys.path:
        sys.path.insert(0, str(module_dir))
        log.info(f"📚 Chemin ajouté au PYTHONPATH : {module_dir}")

    # Installation des dépendances si besoin (Colab uniquement)
    if env == "colab":
        req_file = root / "requirements_sta211.txt"
        if not req_file.exists():
            log.warning(f"⚠️ Fichier {req_file.name} non trouvé. Création temporaire.")
            requirements = [
                "pandas==2.2.2",
                "numpy>=1.26.0,<2.0.0",
                "scikit-learn==1.6.1",
                "scipy==1.15.3",
                "joblib==1.5.1",
                "imbalanced-learn==0.13.0",
                "matplotlib==3.10.0",
                "seaborn==0.13.2",
                "missingno==0.5.2",
                "plotly==6.1.2",
                "prince==0.16.0",
                "umap-learn==0.5.7",
                "MiniSom==2.3.5",
                "xgboost==2.1.4",
                "mlxtend==0.23.4",
                "tqdm==4.67.1",
                "ipython==8.18.1",
                "rich==13.7.1",
                "pyarrow==15.0.2",
                "catboost==1.2.5"
            ]
            with open(req_file, "w") as f:
                f.write("\n".join(requirements))
            log.info(f"✅ Fichier {req_file} créé temporairement.")
        _install_if_needed(req_file, sentinel="catboost")

    # Création des chemins
    paths = setup_project_paths(root_dir=root)
    paths["OUTPUTS_DIR"] = root / "outputs"
    paths["FIGURES_MODELING_DIR"] = paths["FIGURES_DIR"] / "modeling"
    paths["THRESHOLDS_DIR"] = paths["OUTPUTS_DIR"] / "modeling" / "thresholds"

    for p in (paths["OUTPUTS_DIR"], paths["FIGURES_MODELING_DIR"], paths["THRESHOLDS_DIR"]):
        p.mkdir(parents=True, exist_ok=True)
        log.info(f"📁 Dossier créé ou vérifié : {p}")

    # Configuration d'affichage
    set_display_options()

    # Configuration projet
    project_config = create_config(
        project_name="STA211 Challenge",
        author="Maoulida Abdoullatuf",
        version="2.0",
        random_state=42,
        model_dir=paths["MODELS_DIR"]
    )

    # Affichage des versions des bibliothèques
    versions = {"pandas": pd.__version__, "ipython": IPython.__version__}
    for lib in extra_libs:
        try:
            versions[lib] = __import__(lib).__version__
        except ModuleNotFoundError:
            versions[lib] = "—"

    log.info("🧪 Versions des bibliothèques :\n" + "\n".join(f"  · {k:<9}: {v}" for k, v in versions.items()))
    log.info("✅ Initialisation complète réussie")

    display_paths(paths)

    return {
        "paths": paths,
        "PROJECT_NAME": project_config.project_name,
        "AUTHOR": project_config.author,
        "VERSION": project_config.version,
        "RANDOM_STATE": project_config.random_state,
        "CONFIG": project_config,
        "PROJECT_ROOT": root,
        "LIB_VERSIONS": versions,
        "ENV": env
    }
